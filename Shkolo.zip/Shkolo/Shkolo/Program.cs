﻿using System.Text.Json;
using System.Text.Json.Nodes;

JsonSerializerOptions options = new JsonSerializerOptions() { WriteIndented = true };

File.WriteAllText("data.json", "");
string str = JsonSerializer.Serialize("black", options);
